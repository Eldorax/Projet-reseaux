#!/bin/sh

ip addr add 172.16.2.1/28 dev tun0
